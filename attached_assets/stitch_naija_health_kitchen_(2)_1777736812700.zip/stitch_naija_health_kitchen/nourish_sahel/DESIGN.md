# Design System Document: Editorial Vitality

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Earth’s Apothecary."** 

We are moving away from the "clinical" look of typical health apps—the cold blues and sterile whites—and embracing a high-end editorial aesthetic that celebrates Nigerian culinary heritage through a lens of modern wellness. This design system treats food as medicine and the screen as a curated plate. 

To break the "template" look, we utilize **Asymmetric Composition** and **Layered Tactility**. Elements should not always sit in rigid boxes; they should overlap, bleed off-canvas, and breathe. Use generous white space (white space here is the warm `#fff8f4`) to signal luxury and intentionality.

---

## 2. Colors: The Natural Palette
Our palette is rooted in the earth: the deep greens of Ugu leaves (`primary`), the golden hues of unrefined palm oil (`tertiary`), and the rich terracotta of clay pots (`secondary`).

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to define sections. We define boundaries through **Tonal Shifts**. 
- A section of content should be separated from the background by shifting from `surface` (#fff8f4) to `surface-container-low` (#f9f2ee). 
- Horizontal rules are prohibited. Use 24px or 32px of vertical padding to signal a change in context.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of fine stationery.
- **Base Layer:** `surface` (#fff8f4)
- **Content Blocks:** `surface-container` (#f3ede8)
- **Elevated Cards:** `surface-container-lowest` (#ffffff) sitting atop a `surface-container-high` (#ede7e3) background.

### The "Glass & Gradient" Rule
For floating navigation or top-level overlays, use **Glassmorphism**. Apply `surface` with 80% opacity and a 16px backdrop blur. 
**Signature Textures:** For primary CTAs, use a subtle linear gradient from `primary` (#154212) to `primary_container` (#2d5a27) at a 135-degree angle. This adds "soul" and depth, preventing the button from looking like a flat digital sticker.

---

## 3. Typography: The Editorial Voice
We use a dual-typeface system to balance heritage with modern legibility.

*   **Display & Headlines (Epilogue):** This is our "Editorial" voice. Epilogue's weight provides an authoritative yet slightly organic feel. Use `display-lg` for hero nutrition facts and `headline-md` for recipe titles.
*   **Body & Labels (Manrope):** Manrope is our "Functional" voice. It is clean, highly legible, and modern. Use `body-lg` for ingredient lists and `label-md` for micro-metadata (e.g., "High Protein").

**Hierarchy Tip:** Pair a `headline-sm` in `primary` color with a `label-md` in `secondary` (Terracotta) to create a sophisticated, multi-tonal typographic block that feels designed, not just typed.

---

## 4. Elevation & Depth
Depth is achieved through **Tonal Layering** rather than structural lines.

*   **The Layering Principle:** To lift a card, place a `surface-container-lowest` (#ffffff) element onto a `surface-container-low` (#f9f2ee) background. The subtle 2% shift in value creates a "soft lift."
*   **Ambient Shadows:** If a shadow is required for a floating Action Button, use the `on-surface` color (#1d1b19) at **4% opacity** with a **32px blur** and **8px Y-offset**. This mimics natural sunlight hitting a soft surface.
*   **The "Ghost Border" Fallback:** If a container lacks contrast (e.g., on certain mobile screens), use the `outline-variant` (#c2c9bb) at **15% opacity**. Never use a 100% opaque border.
*   **Glassmorphism:** Use for "Sticky" headers. It allows the vibrant food photography to bleed through the UI, making the app feel immersive.

---

## 5. Components

### Buttons
*   **Primary:** Gradient from `primary` to `primary-container`. `xl` (1.5rem) roundedness. Text in `on-primary`.
*   **Secondary:** `surface-container-highest` background with `primary` text. No border.
*   **Tertiary:** Transparent background, `secondary` (Terracotta) text, bold weight. Use for "Read More" or "View All."

### Cards & Lists
*   **No Dividers:** Lists are separated by 16px spacing and subtle background alternates (`surface` vs `surface-container-low`).
*   **Image-First:** Cards should use `xl` (1.5rem) corner radius for images to feel friendly and organic.

### Chips (Dietary Tags)
*   **Selection Chips:** Use `tertiary-fixed` (#ffdf96) with `on-tertiary-fixed` (#251a00) text to highlight health benefits (e.g., "Keto," "Heart Healthy"). This gold tone acts as a "seal of quality."

### Input Fields
*   **Text Inputs:** Use `surface-container-lowest` as the fill. The label should be `label-md` in `outline`. On focus, the "Ghost Border" becomes `primary` at 50% opacity.

### Custom Component: The "Nutrient Gauge"
*   A custom progress bar using a `primary` (Green) track and a `tertiary` (Gold) indicator to show the balance of a meal. Avoid "Red" for errors; use `secondary` (Terracotta) to keep the vibe warm and culinary.

---

## 6. Do's and Don'ts

### Do:
*   **Do** use asymmetrical layouts where images overlap background containers.
*   **Do** use `secondary` (Terracotta) to highlight "Medical/Trust" info, like calorie counts or doctor notes, to make them feel warm.
*   **Do** prioritize high-quality photography of raw ingredients (ginger, okra, peppers) as background accents.

### Don't:
*   **Don't** use pure black (#000000). Use `on-surface` (#1d1b19) for all text.
*   **Don't** use sharp corners. Everything must use at least the `DEFAULT` (0.5rem) roundedness to maintain a "natural" feel.
*   **Don't** use standard "Medical Blue." Trust is built here through professional typography and organic tones, not clinical clichés.